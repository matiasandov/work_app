package com.example.work_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

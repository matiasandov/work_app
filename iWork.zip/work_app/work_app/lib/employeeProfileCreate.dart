import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'feedEmployee.dart';
import 'package:flutter/scheduler.dart' show timeDilation;
//import 'package:image_picker/image_picker.dart';
//import 'package:work_app/imageCapture.dart';

class workExperience extends StatelessWidget {
  const workExperience({
    //variable global text
    required this.text,
    required this.description,
    required this.duration,
    required this.animationController,
    Key? key,
  }) : super(key: key);

  //variable global de texto
  final String text;
  final String description;
  final String duration;

  //guardar controlador de animaciones
  final AnimationController animationController;

  @override
  Widget build(BuildContext context) {
    return SizeTransition(
      sizeFactor:
      //se accedera al animationController de la clase para lograr la animacion deseada y el efecto es de desvanecerse
      CurvedAnimation(parent: animationController, curve: Curves.easeOut),  // NEW
      //se alineara la animacion al eje
      axisAlignment: 0.0,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 10.0),

        //insertas fila
        child: Row(
          //alinea la columna en el centro del eje horizontal y la pone ajustada a a izquierda
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: const EdgeInsets.only(right: 16.0),
              //avatar del mensaje (foto de perfil), que realmente sera la primera letra de tu nombre
              
            ),

            //columna con texto del mensaje que recibira y el nombre del que envia el mensaje
            Column(
              //alinea la columna en el centro del eje horizontal y la pone ajustada a a izquierda
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                //texto del nombre de quien envia el mensaje
                Text(text, style: Theme.of(context).textTheme.headline4),

                //contendor con texto del mensaje
                Container(
                  margin: const EdgeInsets.only(top: 5.0),
                  child: Text(description),
                ),
                
                //duracion
                Text(duration)

              ],
            ),
          ],
        ),
      ),
    );
  }
}



class employeeCreateScreen extends StatelessWidget {

  employeeCreateScreen({Key? key}) : super(key: key);





  @override
  Widget build(BuildContext context) {
    return employeeScreen();
  }
}

class employeeScreen extends StatefulWidget {
  const employeeScreen({Key? key}) : super(key: key);

  @override
  _employeeScreenState createState() => _employeeScreenState();
}

class _employeeScreenState extends State<employeeScreen> with TickerProviderStateMixin{
  //esto es un objeto global que manejara el texto ingresado
  final _textController = TextEditingController();
  final yearController = TextEditingController();
  final experienceController = TextEditingController();
  final socialController = TextEditingController();

  String _value = "Person";
  bool selected1 = false;
  bool selected2 = false;
  bool selected3 = false;
  bool selected4 = false;
  bool selected5 = false;
  bool selected6 = false;
  bool selected7 = false;
  bool selected8 = false;
  bool selected9 = false;
  bool selected10 = false;
  bool selected11 = false;


  //lista de objetos ChatMessage para ir agregando los mensajes cronologicmente
  final List<workExperience> _works = [];      // NEW

  //Para poner de nuevo el cursor en el chat despues de enviar un mensaje
  final FocusNode _focusNode = FocusNode();

  late  String area = "";

  late  String interest = "";

  //esta clase se llama en _buildTextComposer y limpair el input field una vez que se apreiete el  submitted
  void _handleSubmitted(String text, String description, String duration) {
    _textController.clear();


    //el text que reciba lo guardara en el objecto de ChatMessage que se esta creando cada vez que se oprime el boton - constructor de la clase
    var message = workExperience( // NEW
      text: text,
      description: description,
      duration: duration,
      animationController: AnimationController( // NEW
        duration: const Duration(milliseconds: 700), // NEW
        //indica que la animacion se sincronizara con la creacion de este objeto
        vsync: this, // NEW
      ), // NEW
    );
    setState(() {                   // NEW
      _works.insert(0, message); // NEW
    });

    //metodo para ponerl el enfoque donde debe de ser despues de que se haya hecho submit
    _focusNode.requestFocus();

    //se va a reproudcir la animacion cada vez se oprima el boton
    message.animationController.forward();
  }

  void _employeeFeed() async {
    Navigator.of(context).push(
      //widget de builder para abrir nueva pagina al hacer push al stack de navegacion
      MaterialPageRoute(
        builder: (context) {


          //estructura de la pagina
          return feedEmployee();
        },
      ),
    );
  }



  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text("Register as an Employee"),
      ),
      body: Center(

        child: Column(

          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            const Text(
              'Fill the following fields ',
            ),

            

            //flexible es un widget que permitira que lo ue este dentro se ajuste, es decir el controllador de texto y el boton
            Flexible(              // NEW
              //Widget para inout del texto
              child: TextField(
                //se indica el controlador de texto definido antes
                controller: _textController,
                //al darle return se llamaria a este metodo
                //onSubmitted: _handleSubmitted,
                //style -> hara que el chat se ajuste al margen del celular y asi

                decoration:
                const InputDecoration.collapsed(hintText: 'Name of employee'),

              ),
            ),

            Flexible(              // NEW
              //Widget para inout del texto
              child: TextField(
                //se indica el controlador de texto definido antes
                controller: yearController,
                //al darle return se llamaria a este metodo
                //onSubmitted: _handleSubmitted,
                //style -> hara que el chat se ajuste al margen del celular y asi

                decoration:
                const InputDecoration.collapsed(hintText: 'Years of experience'),

              ),
            ),

            Flexible(              // NEW
              //Widget para inout del texto
              child: TextField(
                //se indica el controlador de texto definido antes
                controller: experienceController,
                //al darle return se llamaria a este metodo
                //onSubmitted: _handleSubmitted,
                //style -> hara que el chat se ajuste al margen del celular y asi

                decoration:
                const InputDecoration.collapsed(hintText: 'Describe briefly your work experience'),

              ),
            ),

            Flexible(              // NEW
              //Widget para inout del texto
              child: TextField(
                //se indica el controlador de texto definido antes
                controller: socialController,
                //al darle return se llamaria a este metodo
                //onSubmitted: _handleSubmitted,
                //style -> hara que el chat se ajuste al margen del celular y asi

                decoration:
                const InputDecoration.collapsed(hintText: 'Enter the URL to any social media profile of yours'),

              ),
            ),






            //Categories
            Flexible(
              
              child: Row(
                children: [
                  Text("Select your areas of interest"),

                  
                  FilterChip(
                      label: Text("Home Services"),
                      selected: selected1,
                      onSelected: (bool value){
                        interest = 'Home Services';
                        selected1 = value;
                        setState(() {

                        });
                  },
                ),

                FilterChip(
                      label: Text("Restaurants, Hospitality, and Entertainment"),
                      selected: selected2,
                      onSelected: (bool value){
                        interest = 'Restaurants, Hospitality, and Entertainment';
                        selected2 = value;
                        setState(() {

                        });
                  },
                ),

                FilterChip(
                      label: Text("Driving Services"),
                      selected: selected3,
                      onSelected: (bool value){
                        interest = 'Driving Servicest';
                        selected3 = value;
                        setState(() {

                        });
                  },
                ),

                 FilterChip(
                      label: Text("Healthcare"),
                      selected: selected4,
                      onSelected: (bool value){
                        interest = 'Healthcare';
                        selected4 = value;
                        setState(() {

                        });
                  },
                ),

                FilterChip(
                      label: Text("Personal Assistance"),
                      selected: selected5,
                      onSelected: (bool value){
                        interest = 'Personal Assistance';
                        selected5 = value;
                        setState(() {

                        });
                  },
                ),

                FilterChip(
                      label: Text("Construction Services"),
                      selected: selected6,
                      onSelected: (bool value){
                        interest = 'Construction Services';
                        selected6 = value;
                        setState(() {

                        });
                  },
                ),

                  
                ],
              ),
            ),


            //Ciudad
            Flexible(

              child: Row(
                children: [
                  Text("Select cities of interest"),

                  FilterChip(
                      label: Text("Mexico City"),
                      selected: selected7,
                      onSelected: (bool value){
                        area = 'Mexico City';
                        selected7 = value;
                        setState(() {

                        });
                  },
                ),

                FilterChip(
                      label: Text("Toluca"),
                      selected: selected8,
                      onSelected: (bool value){
                        area = 'Toluca';
                        selected8 = value;
                        setState(() {

                        });
                  },
                ),
                  
                  FilterChip(
                      label: Text("Cuernavaca"),
                      selected: selected9,
                      onSelected: (bool value){
                        area = 'Cuernavaca';
                        selected9 = value;
                        setState(() {

                        });
                  },
                ),

                FilterChip(
                      label: Text("Puebla"),
                      selected: selected10,
                      onSelected: (bool value){
                        area = 'Puebla';
                        selected10 = value;
                        setState(() {

                        });
                  },
                ),

                  
                  FilterChip(
                      label: Text("Guadalajara"),
                      selected: selected11,
                      onSelected: (bool value){
                        area = 'Guadalajara';
                        selected11 = value;
                        setState(() {

                        });
                  },
                ),

                  
                ],
              ),
            ),

            Flexible(
                child: Row(
                    children: const [

                      Text("Upload files that can evidence some of your past jobs")
                      //ImageCapture()

                    ]//children
                )
            ),


            FloatingActionButton.extended(
              backgroundColor: const Color(0xff03dac6),
              foregroundColor: Colors.black,
              onPressed: () => {
                _employeeFeed(),
                sendEmployeeData(
                  //String name, String experience, String years,String location, String socials, String interest
                  _textController.text, experienceController.text , yearController.text ,area, socialController.text, interest)
              },
              icon: Icon(Icons.add),
              label: Text('CREATE PROFILE'),
            )







          ],
        ),
      ),


      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  Future<http.Response> sendEmployeeData(String name, String experience, String years,String location, String socials, String interest  ) {
  return http.post(
    Uri.parse('http://localhost:3000/employee?name='+name+'&'+'experience='+experience+'&'+'years='+years+'&'+'location='+location+'&'+'socials='+socials+'&'+'category='+interest))
    
  ;
}



}
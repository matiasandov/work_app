import 'dart:html';

const keyId = 'idemployees';
const keyName = 'name';
const keyExpe = 'experience';
const keyYear = 'years';
const keyLoca = 'location';
const keySoci = 'socials';
const keyCate = 'category';

class EmployeeModel {
  int idemployees = 0;
  String name = '';
  String experience = '';
  int years = 0;
  String location = '';
  String socials = '';
  String category = '';

 EmployeeModel() {
    this.name = 'Servicio no disponible';
  }

  EmployeeModel.fromJSON(Map<String, dynamic> json) {
    this.idemployees = json[keyId];
    this.name = json[keyName];
    this.experience = json[keyExpe];
    this.years = json[keyYear];
    this.location = json[keyLoca];
    this.socials = json[keySoci];
    this.category = json[keyCate];
  }
  }